package com.viaJava.viaJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViaJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViaJavaApplication.class, args);
	}

}
